Project 1: What Does Your Vision Model See?
Team: Aadya Arora (aarora24) and sroy45
Course: EN 520.465/665 Machine Perception, Fall 2026

How to rerun on Colab:
1. Upload code/notebooks/ to Colab and copy our photos/ folder to MyDrive/p1/photos/ (same layout: B1/, B3/, B5/).
2. Open each notebook in a fresh session (Runtime > Disconnect and delete runtime in between), choose a T4 GPU for
   P1_A, P1_B and P1_665, finish the Google Drive pop-up in the first cell, then Runtime > Run all.
   Locally, set P1_ROOT to a project folder (it defaults to ./p1) and put the photos in <P1_ROOT>/photos/.
3. Run the notebooks in this order; they share one project folder (MyDrive/p1/ on Colab):
  1. P1_0_Setup_and_Data.ipynb        VOC 2012 download, 64/224 px crops, splits, photo self-test
  2. P1_A_Classifier_Ladder.ipynb     A1-A6 training, checkpoints in p1/checkpoints/, Table 2
  3. P1_V_Look_Inside.ipynb           V1-V5 figures
  4. P1_B_Your_Photos.ipynb           B1, B3, B4, B5 (photos in p1/photos/)
  5. P1_665_Frozen_vs_Finetuned.ipynb 665 extension, Figure 1 curves
Outputs: results in p1/results/, figures in report_template/ (next to the p1/ folder).

Table & Figure Mapping (numbering as in report.pdf):
- Table 1 (crop counts per split): P1_0_Setup_and_Data (crop_counts) and P1_A_Classifier_Ladder (A1 cell)
- Table 2 (classifier ladder): P1_A_Classifier_Ladder, "Table 1 and learning curves" cell -> p1/results/table1.csv
- Table 3 (B1 photos vs VOC): P1_B_Your_Photos, Part B pipeline -> p1/results/b1_results.json
- Table 4 (B3 per-object outcomes): P1_B_Your_Photos -> p1/results/b3_per_object.json, p1/results/b3_results.csv
- Table 5 (B5 repair summary): P1_B_Your_Photos -> p1/results/b5_summary.json, p1/results/b5_results.csv
- Table 6 (665 frozen vs fine-tuned): P1_665_Frozen_vs_Finetuned -> p1/results/665_results.json
- Figure 1 (training curves): P1_665_Frozen_vs_Finetuned -> report_template/curves.pdf
- Figure 2 (V1 class means and A1 weights): P1_A_Classifier_Ladder and P1_V_Look_Inside -> report_template/v1_linear_weights.pdf
- Figure 3 (V2 Gabor bank and HOG cells, V3 MLP units, V5 patch PCs and position similarity): P1_V_Look_Inside
  -> report_template/v2_*.pdf, v3_mlp_units.pdf, v5_*.pdf
- Figure 4 (V4 CNN kernels and top-activating crops): P1_V_Look_Inside -> report_template/v4_*.pdf
- Figure 5 (B3 curves): P1_B_Your_Photos -> report_template/fig_b3_series.pdf
- Figure 6 (B4 minimal pairs): P1_B_Your_Photos -> report_template/b4_pair*_a.png, b4_pair*_b.png
- Figure 7 (665 rotation plot): P1_665_Frozen_vs_Finetuned -> report_template/665_rotation.pdf
The top-level b3_results.csv (A2, A4, A6-H, plus the A6-frozen rotation rows from P1_665) and b5_results.csv are
copies of p1/results/b3_results.csv and p1/results/b5_results.csv.

Package Versions:
- Python 3.10+ (verified end to end with Python 3.11, torch 2.15, timm 1.0.30, OpenCV 4.14 on Apple MPS)
- PyTorch 2.0+
- timm 1.0.30 (pinned by the provided setup code)
- torchvision 0.15+
- OpenCV (cv2) 4.7+ (below 5; needs cv2.HOGDescriptor)
- scikit-learn 1.2+
- numpy 1.24+
- pandas 2.0+
- matplotlib 3.7+
- Pillow 9.5+, pillow-heif

Random Seeds:
- Data split: seed 0 (np.random.default_rng(0))
- A1-A5 initialization and batch order: seed 0 (torch.manual_seed(0), np.random.default_rng(0))
- A6-H, A6-L and the 665 frozen-feature head initialization: seed 1 (torch.manual_seed(1))
- B5 mixed batches: seed 42 (np.random.RandomState(42))

B4 Minimal Pairs (photos/B4/; all three reuse B3 photos):
- pair1_a.jpg, pair1_b.jpg: tvmonitor/object2, baseline vs occlusion_half
  (= photos/B3/tvmonitor/object2/baseline.jpg and occlusion_half.jpg)
- pair2_a.jpg: chair/object2 baseline (= photos/B3/chair/object2/baseline.jpg); rotation pair: the second photo is
  this photo rotated by 90 degrees in code (rotate_photo), so only the source photo is submitted
- pair3_a.jpg, pair3_b.jpg: tvmonitor/object1, baseline vs occlusion_half
  (= photos/B3/tvmonitor/object1/baseline.jpg and occlusion_half.jpg); completed by the largest drop in A6-H's
  true-class probability, as the handout prescribes when fewer than three correct/incorrect pairs exist

B5 Repair: factor rotation, condition 180 degrees (the largest A6-H drop in B3). The loaders rotate the adaptation
photos and each held-out ordinary.jpg by 180 degrees; challenge.jpg is not used for a rotation repair.

Held-out Objects for B5:
- bicycle: bicycle/heldout (photos/B5/heldout/bicycle/ordinary.jpg)
- bottle: bottle/heldout (photos/B5/heldout/bottle/ordinary.jpg)
- chair: chair/heldout (photos/B5/heldout/chair/ordinary.jpg)
- pottedplant: pottedplant/heldout (photos/B5/heldout/pottedplant/ordinary.jpg)
- tvmonitor: tvmonitor/heldout (photos/B5/heldout/tvmonitor/ordinary.jpg)
